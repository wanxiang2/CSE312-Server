from pymongo import MongoClient
from util.response import Response
import uuid
from util.database import chat_collection
import json
import html

def create_message(request, handler):
    res = Response()
    response_headers = {}
    response_body = "Message Sent"

    response_headers["Content-Type"] = "text/plain; charset=UTF-8"
    response_headers["Content-Length"] = str(len(response_body))

    res.headers(response_headers)

    cookie_headers = {}

    message_id = str(uuid.uuid4())
    session = str(uuid.uuid4())
    author = str(uuid.uuid4())

    #print("\n\nIn Create Message\n\n")
    #print("\n\n" + str(request.cookies) + "\n\n")

    if "session" in request.cookies:
        #print("\n\nA\n\n")
        results = list(chat_collection.find({"session": request.cookies["session"]}))
        if results:
            #print("\n\nB\n\n")
            author = results[0]["author"]
            session = results[0]["session"]
        else:
            session = request.cookies["session"]
    
    else:
        #print("\n\nC\n\n")
        session = session + "; Max-Age=10800"
        cookie_headers["session"] = session
        session = session.rstrip("; Max-Age=10800")

    #cookie_headers["id"] = message_id

    res.cookies(cookie_headers)

    res.text(response_body)

    request_body = json.loads(request.body)
    user_message = request_body["content"]

    database_entry = {}
    database_entry["author"] = author
    database_entry["id"] = message_id
    database_entry["content"] = html.escape(user_message)
    database_entry["updated"] = False
    database_entry["session"] = session

    chat_collection.insert_one(database_entry)

    

    handler.request.sendall(res.to_data())


def get_message(request, handler):
    res = Response()
    response_headers = {}

    results = list(chat_collection.find({}, {"_id": 0, "session": 0}))

    json_body = {}
    json_body["messages"] = results
    #json_body = json.dumps(json_body, default=str)


    #print(list(chat_collection.find({})))
    #print("\n\n" + json_body + "\n\n")


    

    res.json(json_body)

    json_body = json.dumps(json_body, default=str)
    body_length = str(len(json_body.encode()))
    response_headers["Content-Length"] = body_length

    res.headers(response_headers)




    handler.request.sendall(res.to_data())



def update_message(request, handler):
    res = Response()
    response_headers = {}

    request_body = json.loads(request.body.decode())
    updated_message = request_body["content"]

    message_id = request.path.lstrip("/api/chats/")
    if "session" in request.cookies:
        results = list(chat_collection.find({"id": message_id, "session": request.cookies["session"]}))
        if results:
            update = chat_collection.update_one({"id": message_id, "session": request.cookies["session"]}, {"$set": {"content": updated_message, "updated": True}})

            response_headers["Content-Type"] = "text/plain; charset=UTF-8"

            response_message = "200 OK Updated"
            response_headers["Content-Length"] = str(len(response_message))

            res.headers(response_headers)
            res.text(response_message)
            handler.request.sendall(res.to_data())
            return
        
        # Look over this error handling part again
    res.set_status(403, "Forbidden")
    response_headers["Content-Type"] = "text/plain; charset=UTF-8"
    error_message = "403 Forbidden"
    response_headers["Content-Length"] = str(len(error_message))
    res.headers(response_headers)
    res.text(error_message)
    handler.request.sendall(res.to_data())


def delete_message(request, handler):
    res = Response()
    response_headers = {}

    message_id = request.path.lstrip("/api/chats/")
    if "session" in request.cookies:
        results = list(chat_collection.find({"id": message_id, "session": request.cookies["session"]}))
        if results:
            delete = chat_collection.delete_one({"id": message_id, "session": request.cookies["session"]})

            response_headers["Content-Type"] = "text/plain; charset=UTF-8"

            response_message = "200 OK Updated"
            response_headers["Content-Length"] = str(len(response_message))

            res.headers(response_headers)
            res.text(response_message)
            handler.request.sendall(res.to_data())
            return
        
    res.set_status(403, "Forbidden")
    response_headers["Content-Type"] = "text/plain; charset=UTF-8"
    error_message = "403 Forbidden"
    response_headers["Content-Length"] = str(len(error_message))
    res.headers(response_headers)
    res.text(error_message)
    handler.request.sendall(res.to_data())